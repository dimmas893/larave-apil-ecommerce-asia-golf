<?php

namespace Database\Seeders;

use Illuminate\Support\Str;
use App\Models\Address;
use App\Models\AuthorisedDealer;
use App\Models\Brand;
use App\Models\Bundling;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Customer;
use App\Models\DiscountItem;
use App\Models\ExclusiveDistributor;
use App\Models\FlashSale;
use App\Models\Item;
use App\Models\ItemBundling;
use App\Models\ItemPhoto;
use App\Models\ItemVariant;
use App\Models\Coupon;
use App\Models\Discussion;
use App\Models\DiscussionAnswer;
use App\Models\ItemBundlingDetails;
use App\Models\ItemDiscount;
use App\Models\ItemMeta;
use App\Models\ItemReview;
use App\Models\MetaItem;
use App\Models\Order;
use App\Models\OrderCoupon;
use App\Models\OrderDetail;
use App\Models\Pertanyaan;
use App\Models\PertanyaanBalasan;
use App\Models\Product;
use App\Models\Sales;
use App\Models\Stock;
use App\Models\Ulasan;
use App\Models\User;
use App\Models\Wishlist;
use Illuminate\Database\Seeder;

class DataSeeder extends Seeder
{
    public function run()
    {
        $user = User::create([
            'name'    => 'customer',
            'email'    => 'customer@gmail.com',
            'password'    => bcrypt('password'),
            'role' => 'customer'
        ]);
        $address = Address::create([
            'name' => 'Alamat Kantor',
            'subdistrict' => 5779,
            'province' => 5,
            'city' => 419,
            'address' => 'Jl. Taman Kumudasmoro II No.18, Bongsari, Kec. Semarang Barat, Kota Semarang, Jawa Tengah 50148',
            'longitude' => '110.416664',
            'latitude' => '-6.966667',
            'customer_id' => 1,
            'is_active' => true,
        ]);
        $customer = Customer::create([
            'user_id' => $user->id,
            'name' => $user->name,
            'email'    => 'customer@gmail.com',
            'whatsapp' => '0813923968',
            'phone' => '0813923968',
            'address_id' => $address->id
        ]);
        $brand = Brand::create([
            'name' => 'adidas',
            'logo' => 'adidas.jpg',
            'is_authorized' => true,
            'is_exclusive' => true,
        ]);
        $categories = Category::create([
            'name' => 'nama category',
            'structure' => 'structure'
        ]);
        $item = Item::create([
            'number' => '3242442',
            'name' => 'sepatu santai',
            'minimal_order' => 1,
            'is_bestseller' => true,
            'gender' => 'L',
            'brand_id' => $brand->id,
            'category_id' => $categories->id,
            'weight' => 1000,
            'price' => 50000,
            'deskripsi' => 'Brand sepatu lokal saat ini sudah mulai berkembang dengan pesat. Dari segi kualitas, brand sepatu lokal makin berkembang hingga tidak kalah bersaing dengan brand luar. PVN Shoes merupakan brand sepatu lokal yang sangat populer dikalangan para remaja khususnya wanita.'
        ]);
        $itemmeta = ItemMeta::create([
            'item_id' => $item->id,
            'sold' => 4,
            'review' => 3,
            'discussion' => 4,
            'rating' => 4
        ]);
        $product = Product::create([
            'code' => '001',
            'name' => 'sepatu vans',
            'productable_id' => $item->id,
            'productable_type' => 'App\Models\Item',
        ]);
        $itemvariant = ItemVariant::create([
            'code' => Str::random(5),
            'name' => 'item variant 1',
            'item_id' => $item->id,
        ]);




        $itemvariant2 = ItemVariant::create([
            'code' => Str::random(5),
            'name' => 'item variant 2',
            'item_id' => $item->id,
        ]);

        $product2 = Product::create([
            'code' => '002',
            'name' => 'sepatu vans',
            'productable_id' => $itemvariant->id,
            'productable_type' => 'App\Models\ItemVariant',
        ]);
        $stock = Stock::create(
            [
                'item_id' => $item->id,
                'item_varian_id' => $itemvariant->id,
                'amount' => 11,
            ]
        );
        $stock = Stock::create(
            [
                'item_id' => $item->id,
                'item_varian_id' => $itemvariant2->id,
                'amount' => 11,
            ]
        );

        $Coupon = Coupon::create([
            'code' => Str::random(5),
            'description' => 'ini deskription',
            'nominal' => 2000,
            'customer_id' => (int)$customer->id,
            'start_at' => '2022-06-07',
            'end_at' => '2024-06-07',
            'is_active' => false
        ]);

        $ItemPhoto = ItemPhoto::create([
            'item_id' => $item->id,
            'item_variant_id' => $itemvariant->id,
            'filename' =>  'adidas.jpg',
            'is_default' => true
        ]);
        $ItemPhoto = ItemPhoto::create([
            'item_id' => $item->id,
            'item_variant_id' => $itemvariant2->id,
            'filename' =>  'vans.png',
            'is_default' => true
        ]);

        $itemdiscount = ItemDiscount::create([
            'item_id' => $item->id,
            'nominal' => 3000,
            'type' => 'newuser',
            'start_at' => '2022-06-07',
            'end_at' => '2024-06-07'
        ]);
        $itemdiscount2 = ItemDiscount::create([
            'item_id' => $item->id,
            'nominal' => 5000,
            'type' => 'flashsale',
            'start_at' => '2022-06-07',
            'end_at' => '2024-06-07'
        ]);
        $order = Order::create([
            'number' => Str::random(5),
            'customer_id' => $customer->id,
            'address_id' => $address->id,
            'subtotal' => 0,
            'discount' => $itemdiscount->nominal,
            'tax' => 1000,
            'shipping_fee' => 70000,
            'total' => 90000

        ]);
        $orderdetail = OrderDetail::create([
            'order_id' => $order->id,
            'product_id' => $product->id,
            'qty' => 1,
            'price' => 5000,
            'discount' => 1000,
            'total' => 6000
        ]);
        $itemreview = ItemReview::create([
            'item_id' => $item->id,
            'customer_id' => $customer->id,
            'order_id' => $order->id,
            'content' => 'ini content',
            'photo' => 'adidas.jpg',
            'rating' => 4
        ]);

        $discussion = Discussion::create([
            'item_id' => $item->id,
            'content' => 'ini content',
            'customer_id' => $customer->id
        ]);
        $discussion2 = Discussion::create([
            'item_id' => $item->id,
            'content' => 'jawaban',
            'customer_id' => $customer->id
        ]);
        $discussion = DiscussionAnswer::create([
            'item_id' => $item->id,
            'content' => 'ini jawaban 2',
            'discussion_id' => $discussion2->id,
            'user_id' => $customer->id
        ]);
        $discussion = DiscussionAnswer::create([
            'item_id' => $item->id,
            'content' => 'ini jawaban 2',
            'discussion_id' => $discussion2->id,
            'user_id' => $customer->id
        ]);

        $discussion = DiscussionAnswer::create([
            'item_id' => $item->id,
            'content' => 'ini jawaban',
            'discussion_id' => $discussion->id,
            'user_id' => $customer->id
        ]);

        $itembundling = ItemBundling::create([
            'name' => 'name bundling',
            'price' => 4000,
            'saving' => 'saving'
        ]);

        $itembundlingdetail = ItemBundlingDetails::create(
            [
                'item_bundling_id' => $itembundling->id,
                'item_id' => $item->id,
            ],
            [
                'item_bundling_id' => $itembundling->id,
                'item_id' => $item->id,
            ]
        );

        $ordercoupon = OrderCoupon::create([
            'order_id' => $order->id,
            'coupon_id' => $Coupon->id
        ]);

        $wishlist = Wishlist::create([
            'product_id' => $product->id,
            'customer_id' => $customer->id
        ]);
        $cart = Cart::create([
            'product_id' => $product->id,
            'customer_id' => $customer->id,
            'qty' => 2
        ]);
        $cart2 = Cart::create([
            'product_id' => $product2->id,
            'customer_id' => $customer->id,
            'qty' => 1
        ]);
    }
}
